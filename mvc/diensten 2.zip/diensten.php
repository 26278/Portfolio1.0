<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="reset.css">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="fonts.css">
    <link rel="stylesheet" href="diensten.css">
</head>
<body>
<main>

    <div class="project-uitleg">
        <h2 class="project-uitleg--title">Alles in één pakket</h2>
        <p class="project-uitleg--bericht">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
            magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
            commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat
            nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit
            anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut
        </p>
        <img class="project-uitleg--img" src="img/screen_sideways.png" alt="screen/sideways">

        <div class="project-uitleg__property">
            <div class="project-uitleg__property__container">
                <img class="project-uitleg--icon" src="img/tech.png" alt="">
                <h2 class="project-uitleg__property--title">Website</h2>
            </div>
            <p class="project-uitleg__property__text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
                eu fugiat nulla pariatur.
            </p>
        </div>
        <div class="project-uitleg__property">
            <div class="project-uitleg__property__container">
                <img class="project-uitleg--icon" src="img/tools.png" alt="">
                <h2 class="project-uitleg__property--title">Huisstyle</h2>
            </div>
                <p class="project-uitleg__property__text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
                    eu fugiat nulla pariatur.
                </p>
        </div>

        <div class="project-uitleg__property">
            <div class="project-uitleg__property__container">
                <img class="project-uitleg--icon" src="img/shop.png" alt="">
                <h2 class="project-uitleg__property--title">Online Marketing</h2>
            </div>
                <p class="project-uitleg__property__text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
                    eu fugiat nulla pariatur.
                </p>
        </div>
        <a class="project-uitleg__offerte" href="#">
            <button class="project-uitleg__offerte--button">Offerte Aanvragen</button>
        </a>
    </div>
    <div class="keuze-pakket">
        <h2 class="keuze-pakket--title">Keuze Pakket</h2>
        <p class="keuze-pakket--paragraph">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
            dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex
            ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat
            nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit
            anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
            laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa
            qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in.
        </p>
    </div>
    <div class="pakketten">
        <div class="pakketten__website">
            <div class="pakketten__container">
                <img class="pakketten--icon" src="img/tech.png" alt="">
                <h2 class="pakketten--title">Website</h2>
            </div>
            <img class="pakketten--website-img" src="img/screen_front.png" alt="screen_front">
            <p class="pakketten--text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            </p>
            <div class="checklists">
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Éen domeinnaam</p>
                </div>
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Website volledig verzorgd</p>
                </div>
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Uitleg wordpress</p>
                </div>
            </div>
            <a class="pakketten__offerte" href="#">
                <button class="pakketten__offerte--button">Offerte Aanvragen</button>
            </a>
        </div>


        <div class="pakketten__huisstyle">
            <div class="pakketten__container">
                <img class="pakketten--icon" src="img/tools.png" alt="huisstyle">
                <h2 class="pakketten--title">Huisstyle</h2>
            </div>
            <img class="pakketten--huisstijl-img" src="img/website.png" alt="website">
            <p class="pakketten--text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            </p>
            <div class="checklists">
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Éen domeinnaam</p>
                </div>
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Website volledig verzorgd</p>
                </div>
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Uitleg wordpress</p>
                </div>
            </div>
            <a class="pakketten__offerte" href="#">
                <button class="pakketten__offerte--button">Offerte Aanvragen</button>
            </a>
        </div>

        <div class="pakketten__marketing">
            <div class="pakketten__container">
                <img class="pakketten--icon" src="img/shop.png" alt="marketing">
                <h2 class="pakketten--title">Online Marketing</h2>
            </div>
            <img class="pakketten__img-container--img" src="img/shirt.png" alt="shirt">
            <p class="pakketten--text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            </p>
            <div class="checklists">
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Éen domeinnaam</p>
                </div>
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Website volledig verzorgd</p>
                </div>
                <div class="pakketten__checklist">
                    <img class="pakketten__checklist--check" src="img/check.svg" alt="check">
                    <p class="pakketten__checklist--text">Uitleg wordpress</p>
                </div>
            </div>
            <a class="pakketten__offerte" href="#">
                <button class="pakketten__offerte--button">Offerte Aanvragen</button>
            </a>
        </div>
    </div>

</main>
</body>
</html>